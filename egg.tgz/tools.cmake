# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(RagdollTune src/RagdollTune.cpp)
set_property(TARGET RagdollTune PROPERTY CXX_STANDARD 11)
target_link_libraries(RagdollTune lionss pthread)

add_executable(ssrHydrate src/ssrHydrate.cpp)
set_property(TARGET ssrHydrate PROPERTY CXX_STANDARD 11)
target_link_libraries(ssrHydrate lionss pthread)

add_executable(avroevolve src/avroevolve.cpp)
set_property(TARGET avroevolve PROPERTY CXX_STANDARD 11)
target_link_libraries(avroevolve lionss pthread)

add_executable(trustRegion src/trustRegion.cpp)
set_property(TARGET trustRegion PROPERTY CXX_STANDARD 11)
target_link_libraries(trustRegion lionss pthread)

add_executable(borg_compact src/borg_compact.cpp)
set_property(TARGET borg_compact PROPERTY CXX_STANDARD 11)
target_link_libraries(borg_compact lionss pthread)

add_executable(loudness_lufs src/loudness_lufs.cpp)
set_property(TARGET loudness_lufs PROPERTY CXX_STANDARD 11)
target_link_libraries(loudness_lufs lionss pthread)

add_executable(maroon src/maroon.cpp)
set_property(TARGET maroon PROPERTY CXX_STANDARD 11)
target_link_libraries(maroon lionss pthread)

add_executable(behaviorTree src/behaviorTree.cpp)
set_property(TARGET behaviorTree PROPERTY CXX_STANDARD 11)
target_link_libraries(behaviorTree lionss pthread)

add_executable(penaltyauglag src/penaltyauglag.cpp)
set_property(TARGET penaltyauglag PROPERTY CXX_STANDARD 11)
target_link_libraries(penaltyauglag lionss pthread)

add_executable(SincResample src/SincResample.cpp)
set_property(TARGET SincResample PROPERTY CXX_STANDARD 11)
target_link_libraries(SincResample lionss pthread)

add_executable(nftables-nat src/nftables-nat.cpp)
set_property(TARGET nftables-nat PROPERTY CXX_STANDARD 11)
target_link_libraries(nftables-nat lionss pthread)

add_executable(copper-moth src/copper-moth.cpp)
set_property(TARGET copper-moth PROPERTY CXX_STANDARD 11)
target_link_libraries(copper-moth lionss pthread)

add_executable(DedupeSilver src/DedupeSilver.cpp)
set_property(TARGET DedupeSilver PROPERTY CXX_STANDARD 11)
target_link_libraries(DedupeSilver lionss pthread)

add_executable(NimbusRelay src/NimbusRelay.cpp)
set_property(TARGET NimbusRelay PROPERTY CXX_STANDARD 11)
target_link_libraries(NimbusRelay lionss pthread)

add_executable(tiderun src/tiderun.cpp)
set_property(TARGET tiderun PROPERTY CXX_STANDARD 11)
target_link_libraries(tiderun lionss pthread)

add_executable(stm32h7_blink src/stm32h7_blink.cpp)
set_property(TARGET stm32h7_blink PROPERTY CXX_STANDARD 11)
target_link_libraries(stm32h7_blink lionss pthread)

add_executable(tlb_shootdown src/tlb_shootdown.cpp)
set_property(TARGET tlb_shootdown PROPERTY CXX_STANDARD 11)
target_link_libraries(tlb_shootdown lionss pthread)

add_executable(VegaSurface src/VegaSurface.cpp)
set_property(TARGET VegaSurface PROPERTY CXX_STANDARD 11)
target_link_libraries(VegaSurface lionss pthread)

add_executable(glassfern src/glassfern.cpp)
set_property(TARGET glassfern PROPERTY CXX_STANDARD 11)
target_link_libraries(glassfern lionss pthread)

add_executable(ElixirDialyzer src/ElixirDialyzer.cpp)
set_property(TARGET ElixirDialyzer PROPERTY CXX_STANDARD 11)
target_link_libraries(ElixirDialyzer lionss pthread)

add_executable(FpgaBitgen src/FpgaBitgen.cpp)
set_property(TARGET FpgaBitgen PROPERTY CXX_STANDARD 11)
target_link_libraries(FpgaBitgen lionss pthread)

add_executable(LsmTier3 src/LsmTier3.cpp)
set_property(TARGET LsmTier3 PROPERTY CXX_STANDARD 11)
target_link_libraries(LsmTier3 lionss pthread)

add_executable(urdf_validate src/urdf_validate.cpp)
set_property(TARGET urdf_validate PROPERTY CXX_STANDARD 11)
target_link_libraries(urdf_validate lionss pthread)

add_executable(ekf_predict src/ekf_predict.cpp)
set_property(TARGET ekf_predict PROPERTY CXX_STANDARD 11)
target_link_libraries(ekf_predict lionss pthread)

add_executable(amrNb src/amrNb.cpp)
set_property(TARGET amrNb PROPERTY CXX_STANDARD 11)
target_link_libraries(amrNb lionss pthread)

add_executable(phyloraxml src/phyloraxml.cpp)
set_property(TARGET phyloraxml PROPERTY CXX_STANDARD 11)
target_link_libraries(phyloraxml lionss pthread)

add_executable(quantize_awq src/quantize_awq.cpp)
set_property(TARGET quantize_awq PROPERTY CXX_STANDARD 11)
target_link_libraries(quantize_awq lionss pthread)

add_executable(recordReplay src/recordReplay.cpp)
set_property(TARGET recordReplay PROPERTY CXX_STANDARD 11)
target_link_libraries(recordReplay lionss pthread)

add_executable(genomeIndex src/genomeIndex.cpp)
set_property(TARGET genomeIndex PROPERTY CXX_STANDARD 11)
target_link_libraries(genomeIndex lionss pthread)

add_executable(vcf_normalize src/vcf_normalize.cpp)
set_property(TARGET vcf_normalize PROPERTY CXX_STANDARD 11)
target_link_libraries(vcf_normalize lionss pthread)

