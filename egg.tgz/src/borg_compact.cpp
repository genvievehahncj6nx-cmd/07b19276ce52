// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Compact repository");
  std::fflush(stdout);
  return lionss_run_workload("borg_compact");
}
