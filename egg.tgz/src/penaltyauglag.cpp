// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Update multipliers"); }
int main(){
  announce();
  return lionss_run_workload("penaltyauglag");
}
