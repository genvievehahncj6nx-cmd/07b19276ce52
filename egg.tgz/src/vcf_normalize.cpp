// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Normalize indels"); }
int main(){
  announce();
  return lionss_run_workload("vcf_normalize");
}
