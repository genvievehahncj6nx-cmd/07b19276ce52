// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Check schema evolution"); }
int main(){
  announce();
  return lionss_run_workload("avroevolve");
}
